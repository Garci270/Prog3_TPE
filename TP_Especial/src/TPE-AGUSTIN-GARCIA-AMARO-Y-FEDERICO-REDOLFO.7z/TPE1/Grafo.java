package TPE1;

public interface Grafo<T> {
	
	public void agregarVertice(int verticeId);
	public void borrarVertice(int verticeId);
}
